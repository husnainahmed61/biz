<?php
/**
 * Created by PhpStorm.
 * User: Uzair
 * Date: 10/2/2018
 * Time: 11:45 PM
 */
?>

<div class="container">
    <!-- Breadcrumb Start-->
    <ul class="breadcrumb">
        <li><a href="index.html"><i class="fa fa-home"></i></a></li>
        <li><a href="category.html">Electronics</a></li>
    </ul>
    <!-- Breadcrumb End-->
    <div class="row">
        <div class="col-sm-12">
            <h2 class="title text-center"><strong>Thank You</strong></h2>

            <h5 class="text-center">Kindly check your email to verify your account.</h5>
        </div>
    </div>
</div>
