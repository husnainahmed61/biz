<?php
/**
 * Created by PhpStorm.
 * User: Uzair
 * Date: 8/26/2018
 * Time: 2:26 PM
 */
?>

<h2> Bid Rejected </h2>
<br>
<p>Dear <?=$bidderName?></p>
<p>You cancelled your own bid  on this <a href="<?= $auctionUrl?>">auction</a>.</p>
