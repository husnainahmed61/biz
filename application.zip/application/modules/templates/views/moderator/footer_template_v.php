<?php
/**
 * Created by PhpStorm.
 * User: daniyal.nasir
 * Date: 11-Oct-17
 * Time: 4:36 PM
 */
?>


<!-- BEGIN FOOTER -->
<div class="page-footer">
    <div class="page-footer-inner"> 2018 &copy; Saver Order Panel
    </div>
    <div class="scroll-to-top">
        <i class="icon-arrow-up"></i>
    </div>
</div>
<!-- END FOOTER -->

