<link href="<?= base_url('assets/global/plugins/fancybox/source/jquery.fancybox.css')?> " rel="stylesheet" type="text/css" />


<link href="<?= base_url('assets/global/plugins/jquery-file-upload/blueimp-gallery/blueimp-gallery.min.css')?> " rel="stylesheet" type="text/css" />
<link href="<?= base_url('assets/global/plugins/jquery-file-upload/css/jquery.fileupload.css')?> " rel="stylesheet" type="text/css" />
<link href="<?= base_url('assets/global/plugins/jquery-file-upload/css/jquery.fileupload-ui.css')?> " rel="stylesheet" type="text/css" />