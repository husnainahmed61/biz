<link href="<?= base_url('assets/global/plugins/bootstrap-select/css/bootstrap-select.min.css');?>" rel="stylesheet"
      type="text/css"/>