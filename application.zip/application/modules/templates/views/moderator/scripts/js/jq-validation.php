<script src="<?= base_url('assets/global/plugins/jquery-validation/js/jquery.validate.min.js'); ?> " type="text/javascript"></script>
<script src="<?= base_url('assets/global/plugins/jquery-validation/js/additional-methods.min.js'); ?> " type="text/javascript"></script>
