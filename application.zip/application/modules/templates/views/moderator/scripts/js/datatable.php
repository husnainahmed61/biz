<script src="<?= base_url('assets/global/scripts/datatable.js') ?>" type="text/javascript"></script>
<script src="<?= base_url('assets/global/plugins/datatables/datatables.min.js') ?>" type="text/javascript"></script>
<script src="<?= base_url('assets/global/plugins/datatables/plugins/bootstrap/datatables.bootstrap.js') ?>" type="text/javascript"></script>

<script src="<?= base_url('assets/pages/scripts/table-datatables-responsive.js') ?>" type="text/javascript"></script>