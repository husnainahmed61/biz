<script src="../assets/global/plugins/jquery.sparkline.min.js" type="text/javascript"></script>

