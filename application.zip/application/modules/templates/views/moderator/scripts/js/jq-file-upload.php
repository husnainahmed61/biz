<script src="<?= base_url('assets/global/plugins/jquery-file-upload/js/vendor/jquery.ui.widget.js                ')?> " type="text/javascript"></script>
<script src="<?= base_url('assets/global/plugins/jquery-file-upload/js/vendor/tmpl.min.js                        ')?> " type="text/javascript"></script>
<script src="<?= base_url('assets/global/plugins/jquery-file-upload/js/vendor/load-image.min.js                  ')?> " type="text/javascript"></script>
<script src="<?= base_url('assets/global/plugins/jquery-file-upload/js/vendor/canvas-to-blob.min.js              ')?> " type="text/javascript"></script>
<script src="<?= base_url('assets/global/plugins/jquery-file-upload/blueimp-gallery/jquery.blueimp-gallery.min.js')?> " type="text/javascript"></script>
<script src="<?= base_url('assets/global/plugins/jquery-file-upload/js/jquery.iframe-transport.js                ')?> " type="text/javascript"></script>
<script src="<?= base_url('assets/global/plugins/jquery-file-upload/js/jquery.fileupload.js                      ')?> " type="text/javascript"></script>
<script src="<?= base_url('assets/global/plugins/jquery-file-upload/js/jquery.fileupload-process.js              ')?> " type="text/javascript"></script>
<script src="<?= base_url('assets/global/plugins/jquery-file-upload/js/jquery.fileupload-image.js                ')?> " type="text/javascript"></script>
<script src="<?= base_url('assets/global/plugins/jquery-file-upload/js/jquery.fileupload-audio.js                ')?> " type="text/javascript"></script>
<script src="<?= base_url('assets/global/plugins/jquery-file-upload/js/jquery.fileupload-video.js                ')?> " type="text/javascript"></script>
<script src="<?= base_url('assets/global/plugins/jquery-file-upload/js/jquery.fileupload-validate.js             ')?> " type="text/javascript"></script>
<script src="<?= base_url('assets/global/plugins/jquery-file-upload/js/jquery.fileupload-ui.js                   ')?> " type="text/javascript"></script>

<script src="<?= base_url('assets/pages/scripts/form-fileupload.min.js')?>" type="text/javascript"></script>