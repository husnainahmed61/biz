<?php
/**
 * Created by PhpStorm.
 * User: Daniyal Nasir
 * Date: 06-May-18
 * Time: 11:44 PM
 */
?>
<script type="text/javascript" src="<?= base_url("assets_u/vendors/formstone/js/modernizr.js") ?>"></script>
<script type="text/javascript" src="<?= base_url("assets_u/vendors/formstone/js/site.js") ?>"></script>
<script type="text/javascript" src="<?= base_url("assets_u/vendors/formstone/js/upload.js") ?>"></script>
