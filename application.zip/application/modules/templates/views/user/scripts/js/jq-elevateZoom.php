<script type="text/javascript" src="<?= base_url("assets_u/js/jquery.elevateZoom-3.0.8.min.js") ?>"></script>
