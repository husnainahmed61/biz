<?php
/**
 * Created by PhpStorm.
 * User: Daniyal Nasir
 * Date: 08-May-18
 * Time: 2:30 AM
 */
?>
<!-- The Load Image plugin is included for the preview images and image resizing functionality -->
<script src="https://blueimp.github.io/JavaScript-Load-Image/js/load-image.all.min.js"></script>
<!-- The Canvas to Blob plugin is included for image resizing functionality -->
<script src="https://blueimp.github.io/JavaScript-Canvas-to-Blob/js/canvas-to-blob.min.js"></script>
<!-- The Iframe Transport is required for browsers without support for XHR file uploads -->
<script src="<?= base_url("assets_u/vendors/jquery-file-upload/js/jquery.iframe-transport.js")?>"></script>
<!-- The basic File Upload plugin -->
<script src="<?= base_url("assets_u/vendors/jquery-file-upload/js/jquery.fileupload.js")?>"></script>
<!-- The File Upload processing plugin -->
<script src="<?= base_url("assets_u/vendors/jquery-file-upload/js/jquery.fileupload-process.js")?>"></script>
<!-- The File Upload image preview & resize plugin -->
<script src="<?= base_url("assets_u/vendors/jquery-file-upload/js/jquery.fileupload-image.js")?>"></script>
<!-- The File Upload audio preview plugin -->
<script src="<?= base_url("assets_u/vendors/jquery-file-upload/js/jquery.fileupload-audio.js")?>"></script>
<!-- The File Upload video preview plugin -->
<script src="<?= base_url("assets_u/vendors/jquery-file-upload/js/jquery.fileupload-video.js")?>"></script>
<!-- The File Upload validation plugin -->
<script src="<?= base_url("assets_u/vendors/jquery-file-upload/js/jquery.fileupload-validate.js ")?>"></script>
