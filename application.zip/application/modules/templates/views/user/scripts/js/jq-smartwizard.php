<?php
/**
 * Created by PhpStorm.
 * User: Daniyal Nasir
 * Date: 26-Apr-18
 * Time: 1:28 AM
 */
?>
<script type="text/javascript" src="<?= base_url("assets_u/vendors/SmartWizard/dist/js/jquery.smartWizard.js") ?>"></script>
