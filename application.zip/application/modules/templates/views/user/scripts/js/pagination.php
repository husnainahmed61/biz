<?php
/**
 * Created by PhpStorm.
 * User: Daniyal Nasir
 * Date: 16-Oct-18
 * Time: 3:56 PM
 */
?>
<script type="text/javascript" src="<?= base_url("assets_u/vendors/pagination-2.1.4/pagination.js") ?>"></script>
