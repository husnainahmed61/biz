<?php
/**
 * Created by PhpStorm.
 * User: Daniyal Nasir
 * Date: 26-Apr-18
 * Time: 1:28 AM
 */
?>

<link href="<?= base_url( 'assets_u/vendors/SmartWizard/dist/css/smart_wizard.css')?>" rel="stylesheet" type="text/css" />
<link href="<?= base_url( 'assets_u/vendors/SmartWizard/dist/css/smart_wizard_theme_arrows.css')?>" rel="stylesheet" type="text/css" />

