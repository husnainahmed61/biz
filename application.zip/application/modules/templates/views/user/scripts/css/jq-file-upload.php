<?php
/**
 * Created by PhpStorm.
 * User: Daniyal Nasir
 * Date: 08-May-18
 * Time: 2:30 AM
 */
?>

<link rel="stylesheet" type="text/css" href="<?= base_url("assets_u/vendors/jquery-file-upload/css/jquery.fileupload.css")?>">
