<?php
/**
 * Created by PhpStorm.
 * User: Daniyal Nasir
 * Date: 06-May-18
 * Time: 11:44 PM
 */
?>
<link rel="stylesheet" type="text/css" href="<?= base_url("assets_u/vendors/formstone/css/themes/light/upload.css")?>">
<link rel="stylesheet" type="text/css" href="<?= base_url("assets_u/vendors/formstone/css/upload.css")?>">
