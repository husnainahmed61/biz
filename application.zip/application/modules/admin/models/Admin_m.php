<?php
/**
 * Created by PhpStorm.
 * User: daniyal.nasir
 * Date: 17-Oct-17
 * Time: 1:43 PM
 */

class Admin_m extends MY_Model
{
    /**
     * Admin_m constructor.
     */

}