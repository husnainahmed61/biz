
<div class="container tabs-home-cs">
    <div class="product-showcase row">
        <!-- PRODUCT LIST -->
        <div class="product-list grid row" id="producstListResponse">
            <h4 style="margin: 0 auto;display: table;">Please Allow Location to get nearest auctions</h4>
        </div>
        <br>
        <!-- /PRODUCT LIST -->
        <button class="button big dark loadless" style="margin: 0 auto;" onclick="getLocation()"><span>Try It </span></button>
    </div>
</div>
