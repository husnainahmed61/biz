<?php
/**
 * Created by PhpStorm.
 * User: Uzair
 * Date: 8/26/2018
 * Time: 2:26 PM
 */
?>

<h2> Bid Rejected </h2>
<br>
<p>Dear <?=$bidderName?></p>
<p>Your bid has been canceled on this <a href="<?= $auctionUrl?>">auction</a>.</p>
