        <div class="container">
            <div class="col-md-12">
                <div class="panel panel-primary">
                    <div class="panel-heading">
                        Chat
                    </div>

                    <form class="panel-footer" method="post" id="frm-send">
                        <div class="row">
                            <div class="col-md-4">
                                Nickname: <input type="text" id="fld-nickname">
                            </div>

                            <div class="col-md-4">
                                Message: <input type="text" id="fld-message">
                            </div>

                            <div class="col-md-4">
                                <button type="submit" class="btn btn-primary" id="btn-send">Enviar</button>
                            </div>
                        </div>
                    </form>

                    <div class="panel-body" id="messages">

                    </div>
                </div>
            </div>
        </div>
           