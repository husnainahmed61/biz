 <!-- DASHBOARD CONTENT -->
        <div class="dashboard-content">
            <!-- HEADLINE -->
            <div class="headline buttons primary">
                <h4>Your Notifications</h4>
				<a href="#" class="button mid-short primary">Mark all as Read</a>
            </div>
            <!-- /HEADLINE -->

			<!-- PROFILE NOTIFICATIONS -->
			<div class="profile-notifications notification_list">
				

			</div>
			<!-- /PROFILE NOTIFICATIONS -->

			<!-- PAGER -->
			<ul class="pager primary pagination" id="pagination">

<!--                         <div class="pager-item"><p>1</p></div>
                        <div class="pager-item active"><p>2</p></div>
                        <div class="pager-item"><p>3</p></div>
                        <div class="pager-item"><p>...</p></div>
                        <div class="pager-item"><p>17</p></div> -->
            </ul>
           	<div class="pagination_details"></div>
			<!-- /PAGER -->
        </div>
        <!-- DASHBOARD CONTENT -->