<?php
/**
 * Created by PhpStorm.
 * User: daniyal.nasir
 * Date: 07-Dec-17
 * Time: 5:09 PM
 */



if (!function_exists('sendmail')) {
    function ()
    {

    }
}