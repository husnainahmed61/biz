<?php
/**
 * Created by PhpStorm.
 * User: daniyal.nasir
 * Date: 10-Oct-17
 * Time: 4:25 PM
 */

class Vendor_Controller extends MY_Base_Controller
{
    function __construct()
    {
        parent::__construct();
        // echo "Vendor Controller";
    }
}