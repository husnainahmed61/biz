<?php
defined('BASEPATH') OR exit('No direct script access allowed');
/**
 * Created by PhpStorm.
 * User: Daniyal Nasir
 * Date: 01-Jul-18
 * Time: 1:03 AM
 */
class Email_controller extends CI_Email
{

    /**
     * Email constructor.
     */
    public function __construct()
    {
        parent::__construct();
    }



}